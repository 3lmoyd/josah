<!DOCTYPE html>
<html>
    <head>
        <h1>traning JAVASCRIPT</h1>
    </head>



  
    <?php


// Search query
$searchTerm = $_GET['search']; // Assuming the search term is provided in the URL parameter 'search'

// Construct the SQL query
$sql = "SELECT * FROM halwa_table WHERE name LIKE '%$searchTerm%'"; // Modify 'halwa_table' and 'name' based on your actual table and column names

// Execute the query
$result = mysqli_query($connection, $sql);

// Display the search results
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Display the relevant HTML elements with the retrieved data
        echo '<div>';
        echo '<h2>' . $row['name'] . '</h2>';
        echo '<p>' . $row['description'] . '</p>';
        echo '</div>';
    }
} else {
    echo '<p>No results found.</p>';
}

// Close the database connection
mysqli_close($connection);
?>

<?php
// Assuming you have established a database connection

// Insert query
$insertName = $_POST['name']; // Assuming the name value is provided through a form POST request
$insertDescription = $_POST['description']; // Assuming the description value is provided through a form POST request

// Construct the SQL query
$insertSql = "INSERT INTO halwa_table (name, description) VALUES ('$insertName', '$insertDescription')"; // Modify 'halwa_table', 'name', and 'description' based on your actual table and column names

// Execute the insert query
if (mysqli_query($connection, $insertSql)) {
    echo "New record inserted successfully.";
} else {
    echo "Error inserting record: " . mysqli_error($connection);
}

// Delete query
$deleteId = $_GET['id']; // Assuming the ID of the record to delete is provided in the URL parameter 'id'

// Construct the SQL query
$deleteSql = "DELETE FROM halwa_table WHERE id = '$deleteId'"; // Modify 'halwa_table' and 'id' based on your actual table and column names

// Execute the delete query
if (mysqli_query($connection, $deleteSql)) {
    echo "Record deleted successfully.";
} else {
    echo "Error deleting record: " . mysqli_error($connection);
}

// Close the database connection
mysqli_close($connection);
?>



<body>
    
        
              
    </body>
 
    
</html>