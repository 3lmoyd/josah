<?php
// Database configuration
$servername = 'localhost'; // database host
$dbname = 'albustam'; // database name
$username = 'root'; // database username
$password = ''; // database password

$conn = mysqli_connect($servername, $username, $password, $dbname); 
// 2-Check connection
if (!$conn) {  die("Connection failed: " . mysqli_connect_error()); }
else {  print "You are connected to $dbname <br />"; }
    


// Create a table named "sweets"
$sql= "create table albustam_menu (id int(2) primary key, name varchar(40), price int(3));";
$result = mysqli_query($conn, $sql); 

// Insert some data into the "albustam" table
$pdo->query("INSERT INTO albustam_menu (name, price) VALUES ('walnut', 4)");
$pdo->query("INSERT INTO albustam_menu (name, price) VALUES ('Nuts', 6)");
$pdo->query("INSERT INTO albustam_menu (name, price) VALUES ('Omani dates', 6)");
$pdo->query("INSERT INTO albustam_menu (name, price) VALUES ('red sugar', 6)");



// Fetch data from the "albustam" table
$stmt = $pdo->query("SELECT * FROM sweets");
$rows = $stmt->fetchAll();

// Display the results
foreach ($rows as $row) {
    echo $row['name'] . ': $' . $row['price'] . '<br>';
}
?>
