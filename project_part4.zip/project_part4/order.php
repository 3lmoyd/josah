<!DOCTYPE html>
<html>
<head>
	<title>Order Submission Result</title>
</head>
<body>

<?php

// Retrieve the form data
$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$halwa = $_POST['Halwa'];
$size = $_POST['size'];
$delivery = $_POST['delivery'];
$address = $_POST['address'];

// Define a class to represent an order item
class OrderItem {
  public $name;
  public $quantity;
  
  function __construct($name, $quantity) {
    $this->name = $name;
    $this->quantity = $quantity;
  }
}

// Create an array to hold the order items
$items = array();

// Add the selected halwa items to the array
foreach ($halwa as $key => $value) {
  $quantity = $_POST['quantity'][$key];
  $item = new OrderItem($value, $quantity);
  array_push($items, $item);
}

// Define a function to display the order information in a table
function displayOrder($name, $email, $phone, $items, $size, $delivery, $address) {
  echo "<table>";
  echo "<tr><th>Name:</th><td>$name</td></tr>";
  echo "<tr><th>Email:</th><td>$email</td></tr>";
  echo "<tr><th>Phone:</th><td>$phone</td></tr>";
  echo "<tr><th>Halwa:</th><td><ul>";
  foreach ($items as $item) {
    echo "<li>" . $item->name . " - " . $item->quantity . "</li>";
  }
  echo "</ul></td></tr>";
  echo "<tr><th>Size:</th><td>$size</td></tr>";
  echo "<tr><th>Delivery:</th><td>$delivery</td></tr>";
  echo "<tr><th>Address:</th><td>$address</td></tr>";
  echo "</table>";
}

// Display the order information
displayOrder($name, $email, $phone, $items, $size, $delivery, $address);

?>


</body>
</html>
